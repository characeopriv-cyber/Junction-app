# Junction — Ready to Deploy

This folder is a complete, working website project. Follow these steps exactly.

## Step 1 — Create a GitHub repository

1. Go to https://github.com and log in (same account you used for Vercel —
   "characeopriv-cyber").
2. Click the **+** icon (top right) → **New repository**.
3. Name it `junction-app`.
4. Leave it Public or Private (either is fine).
5. Do **NOT** check "Add a README" — leave everything else default.
6. Click **Create repository**.

## Step 2 — Upload these files

1. On the new empty repository page, click **"uploading an existing file"**
   (blue link in the middle of the page).
2. Drag this **entire folder's contents** into the upload box — all files
   and the `src` folder together. (On mobile: tap "choose your files" and
   select all files; you may need to do the `src` folder separately as a
   second upload into a `src` subfolder if your phone doesn't support
   drag-and-drop folders — see Step 2b below if needed.)
3. Scroll down, click **Commit changes**.

### Step 2b — If your phone can't upload the `src` folder directly

GitHub's mobile upload sometimes can't handle folders. If that happens:
1. After uploading the root files (package.json, vite.config.js, etc.),
   go back to the repo's main page.
2. Click **Add file → Create new file**.
3. In the filename box, type `src/main.jsx` (the `src/` prefix
   automatically creates the folder).
4. Paste the contents of `src/main.jsx` into the editor, commit.
5. Repeat for `src/App.jsx` and `src/index.css`.

This is fiddly on mobile — if possible, do this step from a laptop/desktop
browser instead, where drag-and-drop folder upload works normally.

## Step 3 — Connect Vercel

1. Go back to Vercel (where you were).
2. Refresh the "Import Git Repository" screen.
3. `junction-app` should now appear in the list.
4. Click it, then click **Deploy**.
5. Wait about 1–2 minutes while it builds.
6. You'll get a live URL like `junction-app.vercel.app` — that's your
   real, working website.

## What works on the live site

- Full visual interface: intro screen with the speaking AI face,
  the orb discovery feed, Reels, Services marketplace, Investor Zone,
  Vision 2040 tab, verification flow, business pages, transactions —
  everything you've been testing.
- Voice (text-to-speech) — works in real browsers (this was blocked
  only inside Claude's preview sandbox).
- Posting properties/services, navigating, the call UI simulation.

## What does NOT work yet (by design — needs a backend)

- **Junction AI chat replies** will show a message explaining that live
  AI needs a connected backend — this is expected. The visual chat UI
  still works; only the AI-generated responses are disabled until a
  real backend (see the `junction-backend` Next.js scaffold provided
  earlier) is connected with your own Anthropic API key.
- **Nothing is saved permanently** — refreshing the page resets
  everything, since there's still no database. That's the next step
  after this visual testing phase.

## Updating the site later

Any time you want to change something: edit the file on GitHub (or
re-upload a new version of `App.jsx`), commit the change, and Vercel
automatically rebuilds and updates the live site within a minute or two.
No need to repeat the Vercel setup.
